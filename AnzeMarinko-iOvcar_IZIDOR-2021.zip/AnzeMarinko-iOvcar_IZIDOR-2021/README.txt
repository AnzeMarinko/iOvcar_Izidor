# iOvčar IZIDOR

Simulator gibanja ovc in vodenja črede z avtonomnim psom ovčarjem.

Program je nastal za potrebe magistrskega dela z naslovom *Vodenje psa ovčarja s pomočjo umetne inteligence*. Avtor je Anže Marinko,
mentor izr. prof. dr. Iztok Lebar Bajec in somentor doc. dr. Jure Demšar. Avtor je s tem zaključil interdisciplinarni magistrski
študij računalništva in matematike na Fakulteti za matematiko in fiziko (Univerza v Ljubljani) in Fakulteti za računalništvo in
informatiko (Univerza v Ljubljani).

Program zaženete z dvojnim klikom na *iOvcar_Izidor.exe*. V meniju (zgoraj levo) izbirate postavitev kamere, število psov, ovc ...
